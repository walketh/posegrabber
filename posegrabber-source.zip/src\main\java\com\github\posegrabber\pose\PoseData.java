package com.github.posegrabber.pose;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.vector.Vector3d;

/**
 * Класс, хранящий данные о позе игрока
 */
public class PoseData {
    private final PoseType poseType;
    private final Vector3d headRotation;
    private final Vector3d bodyRotation;
    private final Vector3d position;
    private final boolean isMoving;
    private final boolean isSprinting;
    private final boolean onGround;
    private final float health;
    private final float absorption;

    public PoseData(PoseType poseType, PlayerEntity player) {
        this.poseType = poseType;
        this.headRotation = new Vector3d(
            player.xRot,
            player.yRot,
            player.yHeadRot
        );
        this.bodyRotation = new Vector3d(
            player.xRotO,
            player.yRotO,
            player.yBodyRot
        );
        this.position = player.position();
        this.isMoving = player.ddx() != 0 || player.ddz() != 0;
        this.isSprinting = player.isSprinting();
        this.onGround = player.onGround;
        this.health = player.getHealth();
        this.absorption = player.getAbsorptionAmount();
    }

    public PoseType getPoseType() {
        return poseType;
    }

    public Vector3d getHeadRotation() {
        return headRotation;
    }

    public Vector3d getBodyRotation() {
        return bodyRotation;
    }

    public Vector3d getPosition() {
        return position;
    }

    public boolean isMoving() {
        return isMoving;
    }

    public boolean isSprinting() {
        return isSprinting;
    }

    public boolean isOnGround() {
        return onGround;
    }

    public float getHealth() {
        return health;
    }

    public float getAbsorption() {
        return absorption;
    }

    @Override
    public String toString() {
        return String.format("PoseData{type=%s, pos=%s, moving=%b, sprinting=%b}",
            poseType, position, isMoving, isSprinting);
    }

    /**
     * Типы поз игроков
     */
    public enum PoseType {
        STANDING("Стоя"),
        SITTING("Сидя"),
        SLEEPING("Спящий"),
        CRAWLING("Ползком"),
        SWIMMING("Плывёт"),
        FALLING("Падает"),
        CLIMBING("Лазит"),
        FLYING("Летит"),
        SNEAKING("Крадётся"),
        SPIN_ATTACK("Вращение"),
        CUSTOM("Кастомная");

        private final String displayName;

        PoseType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }
    }
}
