package com.github.posegrabber;

import net.minecraftforge.common.ForgeConfigSpec;

public class Config {
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final ForgeConfigSpec.BooleanValue CLIENT_GUI_ENABLED;

    static {
        ForgeConfigSpec.Builder clientBuilder = new ForgeConfigSpec.Builder();

        CLIENT_GUI_ENABLED = clientBuilder
            .comment("Включить отображение GUI с позами игроков")
            .translation("posegrabber.config.guiEnabled")
            .define("guiEnabled", true);

        clientBuilder.comment("Настройки PoseGrabber мода")
            .push("general");

        clientBuilder.pop();

        CLIENT_SPEC = clientBuilder.build();
    }
}
