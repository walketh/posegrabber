package com.github.posegrabber.pose;

import com.github.posegrabber.labymod.LabyModIntegration;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Pose;

/**
 * Менеджер для захвата и управления позами игроков
 */
public class PoseManager {

    /**
     * Захватывает текущую позу игрока
     */
    public PoseData capturePose(PlayerEntity player) {
        PoseType poseType = determinePoseType(player);
        return new PoseData(poseType, player);
    }

    /**
     * Определяет тип позы игрока на основе его состояния
     */
    private PoseType determinePoseType(PlayerEntity player) {
        // Проверка на кастомную позу через LabyMod (если доступно)
        if (LabyModIntegration.isLabyModAvailable() && LabyModIntegration.hasCustomPose(player)) {
            return PoseType.CUSTOM;
        }

        // Проверка стандартных поз Minecraft
        if (player.isPassenger()) {
            return PoseType.SITTING;
        }

        if (player.isSleeping()) {
            return PoseType.SLEEPING;
        }

        if (player.isSwimming()) {
            return PoseType.SWIMMING;
        }

        if (player.isSprinting()) {
            return PoseType.SPRINTING;
        }

        if (player.isCrouching()) {
            return PoseType.SNEAKING;
        }

        if (player.isFallFlying()) {
            return PoseType.FLYING;
        }

        if (player.onClimbable()) {
            return PoseType.CLIMBING;
        }

        if (!player.onGround && player.getDeltaMovement().y < 0) {
            return PoseType.FALLING;
        }

        // Проверка позы через Forge
        Pose forgePose = player.getPose();
        if (forgePose == Pose.CROUCHING) {
            return PoseType.SNEAKING;
        } else if (forgePose == Pose.SWIMMING) {
            return PoseType.SWIMMING;
        } else if (forgePose == Pose.SPIN_ATTACK) {
            return PoseType.SPIN_ATTACK;
        }

        // По умолчанию - стоя
        return PoseType.STANDING;
    }

    /**
     * Получение всех доступных типов поз
     */
    public PoseType[] getAvailablePoseTypes() {
        return PoseType.values();
    }
}
