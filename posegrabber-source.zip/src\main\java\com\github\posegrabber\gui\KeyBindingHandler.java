package com.github.posegrabber.gui;

import com.github.posegrabber.PoseGrabberMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.client.settings.KeyModifier;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.glfw.GLFW;

/**
 * Обработчик клавиш для открытия GUI
 */
public class KeyBindingHandler {
    public static final KeyBinding OPEN_POSE_GUI = new KeyBinding(
        "key.posegrabber.open_gui",
        KeyConflictContext.IN_GAME,
        KeyModifier.NONE,
        GLFW.GLFW_KEY_P,
        "Pose Grabber"
    );

    public KeyBindingHandler() {
        ClientRegistry.registerKeyBinding(OPEN_POSE_GUI);
    }

    @SubscribeEvent
    public void onKeyInput(net.minecraftforge.client.event.InputEvent.KeyInputEvent event) {
        if (OPEN_POSE_GUI.consumeClick()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.screen == null && mc.level != null) {
                mc.setScreen(new PoseOverlayScreen());
            }
        }
    }
}
