package com.github.posegrabber.gui;

import com.github.posegrabber.PoseGrabberMod;
import com.github.posegrabber.pose.PoseData;
import com.mojang.blaze3d.matrix.MatrixStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.TranslationTextComponent;

import java.util.Map;
import java.util.UUID;

/**
 * GUI экран для отображения поз игроков
 */
public class PoseOverlayScreen extends Screen {
    private final PoseGrabberMod mod;
    private boolean showDetails = false;
    private int scrollOffset = 0;
    private int maxScroll = 0;

    public PoseOverlayScreen() {
        super(new TranslationTextComponent("posegrabber.gui.title"));
        this.mod = PoseGrabberMod.getInstance();
    }

    @Override
    protected void init() {
        super.init();

        // Кнопка переключения деталей
        this.addButton(new Button(
            this.width - 220,
            10,
            200,
            20,
            new StringTextComponent(showDetails ? "Скрыть детали" : "Показать детали"),
            button -> {
                showDetails = !showDetails;
                button.setMessage(new StringTextComponent(showDetails ? "Скрыть детали" : "Показать детали"));
            }
        ));

        // Кнопка закрытия
        this.addButton(new Button(
            this.width - 220,
            35,
            200,
            20,
            new StringTextComponent("Закрыть"),
            button -> this.minecraft.setScreen(null)
        ));
    }

    @Override
    public void render(MatrixStack matrixStack, int mouseX, int mouseY, float partialTicks) {
        // Рендер фона
        renderBackground(matrixStack);

        // Заголовок
        drawCenteredString(matrixStack, this.font, "Pose Grabber - Позы игроков",
            this.width / 2, 10, 0xFFFFAA00);

        // Список игроков и их поз
        int startY = 70;
        int x = 20;
        int index = 0;

        Map<UUID, PoseData> playerPoses = mod.getPlayerPoses();

        if (playerPoses.isEmpty()) {
            drawCenteredString(matrixStack, this.font, "Нет игроков в радиусе",
                this.width / 2, startY, 0xFFFFFFFF);
        } else {
            for (Map.Entry<UUID, PoseData> entry : playerPoses.entrySet()) {
                if (index >= scrollOffset && index < scrollOffset + 15) {
                    PlayerEntity player = minecraft.level.getPlayerByUUID(entry.getKey());
                    if (player != null) {
                        PoseData pose = entry.getValue();
                        int y = startY + (index - scrollOffset) * 25;

                        // Имя игрока
                        String playerName = player.getName().getString();
                        String poseType = pose.getPoseType().getDisplayName();

                        // Цвет в зависимости от позы
                        int color = getPoseColor(pose.getPoseType());

                        drawString(matrixStack, this.font, playerName, x, y, 0xFFFFFFFF);
                        drawString(matrixStack, this.font, ": " + poseType,
                            x + this.font.width(playerName), y, color);

                        // Детали
                        if (showDetails) {
                            int detailY = y + 10;
                            drawString(matrixStack, this.font,
                                String.format("  Позиция: %.1f, %.1f, %.1f",
                                    pose.getPosition().x, pose.getPosition().y, pose.getPosition().z),
                                x, detailY, 0xFFAAAAAA);
                            drawString(matrixStack, this.font,
                                String.format("  Движение: %s, Спринт: %s, На земле: %s",
                                    pose.isMoving() ? "Да" : "Нет",
                                    pose.isSprinting() ? "Да" : "Нет",
                                    pose.isOnGround() ? "Да" : "Нет"),
                                x, detailY + 10, 0xFFAAAAAA);
                        }
                    }
                }
                index++;
            }

            // Обновляем максимальный скролл
            maxScroll = Math.max(0, playerPoses.size() - 15);
        }

        // Инструкции
        drawString(matrixStack, this.font, "ESC - Закрыть | Колесо - Скролл",
            20, this.height - 30, 0xFF888888);

        super.render(matrixStack, mouseX, mouseY, partialTicks);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (delta > 0) {
            scrollOffset = Math.max(0, scrollOffset - 1);
        } else {
            scrollOffset = Math.min(maxScroll, scrollOffset + 1);
        }
        return true;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return true;
    }

    private int getPoseColor(PoseData.PoseType poseType) {
        switch (poseType) {
            case STANDING:
                return 0x00FF00;
            case SITTING:
                return 0xFFFF00;
            case SLEEPING:
                return 0x0000FF;
            case CRAWLING:
                return 0xFFA500;
            case SWIMMING:
                return 0x00FFFF;
            case FALLING:
                return 0xFF0000;
            case CLIMBING:
                return 0xFF00FF;
            case FLYING:
                return 0xFFFFFF;
            case SNEAKING:
                return 0x888888;
            case SPIN_ATTACK:
                return 0xFF0000;
            case CUSTOM:
                return 0xFFAA00;
            default:
                return 0xFFFFFF;
        }
    }
}
