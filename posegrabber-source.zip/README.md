# Pose Grabber Mod

Мод для Minecraft 1.16.5 для захвата и отображения поз игроков.

## Особенности

- **Захват всех типов поз**: Стоя, сидя, спящий, ползком, плывёт, падает, лазит, летит, крадётся, вращение, кастомные позы
- **GUI интерфейс**: Отображение поз в реальном времени во время игры
- **Интеграция с LabyMod 3**: Поддержка кастомных поз LabyMod
- **Forge совместимость**: Работает с Forge 36.2.39+

## Требования

- Minecraft 1.16.5
- Forge 36.2.39 или выше
- LabyMod 3.7.4+ (опционально, для кастомных поз)

## Установка

1. Установите Minecraft 1.16.5 с Forge
2. (Опционально) Установите LabyMod 3
3. Скопируйте файл `posegrabber-1.0.0.jar` в папку `mods`
4. Запустите игру

## Управление

### Клавиши
- **P** - Открыть GUI с позами игроков

### Команды
- `/pose` - Включить/выключить GUI
- `/pose gui` - Открыть GUI
- `/pose list` - Показать количество отслеживаемых игроков
- `/pose refresh` - Обновить данные о позах

## Сборка

```bash
# Сборка мода
gradlew build

# Запуск клиента для тестирования
gradlew runClient
```

## Структура проекта

```
e:\ghost\
├── build.gradle              # Конфигурация сборки
├── gradle.properties         # Настройки Gradle
├── settings.gradle           # Настройки проекта
└── src\
    └── main\
        ├── java\
        │   └── com\github\posegrabber\
        │       ├── PoseGrabberMod.java      # Главный класс
        │       ├── Config.java              # Конфигурация
        │       ├── gui\
        │       │   ├── PoseOverlayScreen.java  # GUI экран
        │       │   ├── ModCommands.java        # Команды
        │       │   └── KeyBindingHandler.java  # Обработка клавиш
        │       ├── pose\
        │       │   ├── PoseData.java        # Данные позы
        │       │   └── PoseManager.java     # Менеджер поз
        │       └── labymod\
        │           └── LabyModIntegration.java  # Интеграция с LabyMod
        └── resources\
            ├── META-INF\
            │   └── mods.toml                # Метаданные мода
            └── assets\
                └── posegrabber\
                    └── lang\
                        ├── ru_ru.json       # Русский язык
                        └── en_us.json       # Английский язык
```

## API

### PoseData
Класс содержит информацию о позе игрока:
- Тип позы
- Позиция
- Вращение головы и тела
- Статус движения

### PoseManager
Менеджер для захвата и определения поз игроков.

## Лицензия

MIT

## Авторы

PoseGrabber Team
