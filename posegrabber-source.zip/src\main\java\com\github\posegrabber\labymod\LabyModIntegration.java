package com.github.posegrabber.labymod;

import net.minecraft.entity.player.PlayerEntity;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Интеграция с LabyMod 3 API
 * Работает через рефлексию - мод будет работать и без LabyMod
 */
public class LabyModIntegration {
    private static final Logger LOGGER = LogManager.getLogger("LabyModIntegration");
    private static boolean labymodAvailable = false;
    private static Object labymodAPI = null;

    /**
     * Инициализация интеграции с LabyMod
     */
    public static void init() {
        try {
            // Попытка получить доступ к LabyMod API через рефлексию
            Class<?> labymodClass = Class.forName("net.labymod.api.LabyMod");
            java.lang.reflect.Method getInstanceMethod = labymodClass.getMethod("getInstance");
            labymodAPI = getInstanceMethod.invoke(null);
            labymodAvailable = true;
            LOGGER.info("[PoseGrabber] LabyMod API найден! Кастомные позы доступны.");
        } catch (ClassNotFoundException e) {
            labymodAvailable = false;
            LOGGER.info("[PoseGrabber] LabyMod не найден. Работа без LabyMod.");
        } catch (Exception e) {
            labymodAvailable = false;
            LOGGER.warn("[PoseGrabber] Ошибка инициализации LabyMod: {}", e.getMessage());
        }
    }

    /**
     * Проверка доступности LabyMod API
     */
    public static boolean isLabyModAvailable() {
        return labymodAvailable;
    }

    /**
     * Получение кастомной позы игрока через LabyMod
     */
    public static String getCustomPose(PlayerEntity player) {
        if (!labymodAvailable || labymodAPI == null || player == null) {
            return null;
        }

        try {
            // LabyMod 3 хранит информацию о эмотах/позах в player capabilities
            Class<?> emoteAPI = Class.forName("net.labymod.api.addons.addon.emotes.EmoteAddon");
            if (emoteAPI != null) {
                LOGGER.debug("LabyMod Emote API доступен");
            }
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Проверка, использует ли игрок кастомную позу LabyMod
     */
    public static boolean hasCustomPose(PlayerEntity player) {
        String pose = getCustomPose(player);
        return pose != null && !pose.isEmpty();
    }

    /**
     * Проверка, использует ли игрок LabyMod
     */
    public static boolean isPlayerUsingLabyMod(PlayerEntity player) {
        if (!labymodAvailable || player == null) {
            return false;
        }
        return false; // Упрощённая реализация
    }
}
