package com.github.posegrabber;

import com.github.posegrabber.gui.KeyBindingHandler;
import com.github.posegrabber.gui.ModCommands;
import com.github.posegrabber.gui.PoseOverlayScreen;
import com.github.posegrabber.pose.PoseData;
import com.github.posegrabber.pose.PoseManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.client.events.RenderGameOverlayEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ExtensionPoint;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.network.FMLNetworkConstants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Mod(PoseGrabberMod.MOD_ID)
public class PoseGrabberMod {
    public static final String MOD_ID = "posegrabber";
    private static final Logger LOGGER = LogManager.getLogger(MOD_ID);

    private static PoseGrabberMod instance;
    private PoseManager poseManager;
    private Map<UUID, PoseData> playerPoses;
    private boolean guiEnabled = true;
    private KeyBindingHandler keyBindingHandler;

    public PoseGrabberMod() {
        instance = this;

        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        modBus.addListener(this::clientSetup);

        MinecraftForge.EVENT_BUS.register(this);

        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, Config.CLIENT_SPEC);

        playerPoses = new ConcurrentHashMap<>();
        poseManager = new PoseManager();

        LOGGER.info("PoseGrabber мод инициализирован (LabyMod 3 совместимый)!");
    }

    public static PoseGrabberMod getInstance() {
        return instance;
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        LOGGER.info("Клиентская настройка PoseGrabber");

        // Отключаем проверку совместимости версий для Forge
        ModLoadingContext.get().registerExtensionPoint(
            ExtensionPoint.DISPLAYTEST,
            () -> FMLNetworkConstants.IGNORESERVERONLY
        );

        guiEnabled = Config.CLIENT_GUI_ENABLED.get();

        // Регистрация key binding
        keyBindingHandler = new KeyBindingHandler();
        MinecraftForge.EVENT_BUS.register(keyBindingHandler);

        // Инициализация LabyMod интеграции
        com.github.posegrabber.labymod.LabyModIntegration.init();

        // Регистрация команд
        event.enqueueWork(() -> {
            Minecraft.getInstance().execute(() -> {
                net.minecraftforge.client.ClientRegistry.registerClientCommands(ModCommands::register);
            });
        });
    }

    @net.minecraftforge.eventbus.api.SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START || Minecraft.getInstance().level == null) {
            return;
        }

        updatePlayerPoses();
    }

    private void updatePlayerPoses() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;

        List<UUID> toRemove = new ArrayList<>();

        // Обновляем позы всех игроков в мире
        for (PlayerEntity player : mc.level.players()) {
            if (player instanceof AbstractClientPlayerEntity) {
                UUID playerId = player.getUUID();
                PoseData poseData = poseManager.capturePose(player);
                playerPoses.put(playerId, poseData);
            }
        }

        // Удаляем позы игроков, которые покинули мир
        for (Map.Entry<UUID, PoseData> entry : playerPoses.entrySet()) {
            boolean found = false;
            for (PlayerEntity player : mc.level.players()) {
                if (player.getUUID().equals(entry.getKey())) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                toRemove.add(entry.getKey());
            }
        }

        for (UUID uuid : toRemove) {
            playerPoses.remove(uuid);
        }
    }

    @net.minecraftforge.eventbus.api.SubscribeEvent
    public void onRenderOverlay(RenderGameOverlayEvent.Post event) {
        if (!guiEnabled || event.getType() != RenderGameOverlayEvent.ElementType.ALL) {
            return;
        }

        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null && !playerPoses.isEmpty()) {
            // Рендерим информацию о позах в углу экрана
            int x = 10;
            int y = 10;

            event.getMatrixStack().pushPose();
            event.getMatrixStack().translate(0, 0, 500);

            mc.font.draw(event.getMatrixStack(), "§6=== Pose Grabber ===", x, y, 0xFFFFAA00);
            y += 12;

            for (Map.Entry<UUID, PoseData> entry : playerPoses.entrySet()) {
                PlayerEntity player = mc.level.getPlayerByUUID(entry.getKey());
                if (player != null) {
                    String playerName = player.getName().getString();
                    PoseData pose = entry.getValue();
                    String poseInfo = String.format("§f%s: §a%s", playerName, pose.getPoseType());
                    mc.font.draw(event.getMatrixStack(), poseInfo, x, y, 0xFFFFFFFF);
                    y += 10;
                }
            }

            event.getMatrixStack().popPose();
        }
    }

    public Map<UUID, PoseData> getPlayerPoses() {
        return playerPoses;
    }

    public PoseManager getPoseManager() {
        return poseManager;
    }

    public void toggleGui() {
        guiEnabled = !guiEnabled;
        Config.CLIENT_GUI_ENABLED.set(guiEnabled);
        LOGGER.info("GUI переключено: {}", guiEnabled);
    }

    public boolean isGuiEnabled() {
        return guiEnabled;
    }
}
