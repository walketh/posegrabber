package com.github.posegrabber.gui;

import com.github.posegrabber.PoseGrabberMod;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.command.CommandSource;
import net.minecraft.command.Commands;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.text.StringTextComponent;

/**
 * Команды для управления модом
 */
public class ModCommands {

    public static void register(CommandDispatcher<CommandSource> dispatcher) {
        dispatcher.register(Commands.literal("pose")
            .requires(source -> source.hasPermission(0))
            .executes(ModCommands::togglePose)
            .then(Commands.literal("gui")
                .executes(ModCommands::openGui)
            )
            .then(Commands.literal("list")
                .executes(ModCommands::listPoses)
            )
            .then(Commands.literal("refresh")
                .executes(ModCommands::refreshPoses)
            )
        );
    }

    private static int togglePose(CommandContext<CommandSource> context) {
        PoseGrabberMod.getInstance().toggleGui();
        boolean enabled = PoseGrabberMod.getInstance().isGuiEnabled();

        StringTextComponent message = new StringTextComponent(
            "§6[PoseGrabber] GUI теперь: §a" + (enabled ? "ВКЛ" : "ВЫКЛ")
        );
        context.getSource().sendSuccess(message, false);

        return 1;
    }

    private static int openGui(CommandContext<CommandSource> context) {
        if (context.getSource().getEntity() instanceof ServerPlayerEntity) {
            ServerPlayerEntity player = (ServerPlayerEntity) context.getSource().getEntity();

            StringTextComponent message = new StringTextComponent(
                "§6[PoseGrabber] Откройте GUI через клавишу P"
            );
            context.getSource().sendSuccess(message, false);
        }
        return 1;
    }

    private static int listPoses(CommandContext<CommandSource> context) {
        int count = PoseGrabberMod.getInstance().getPlayerPoses().size();

        StringTextComponent message = new StringTextComponent(
            "§6[PoseGrabber] Отслеживается игроков: §a" + count
        );
        context.getSource().sendSuccess(message, false);

        return 1;
    }

    private static int refreshPoses(CommandContext<CommandSource> context) {
        StringTextComponent message = new StringTextComponent(
            "§6[PoseGrabber] Данные о позах обновлены"
        );
        context.getSource().sendSuccess(message, false);

        return 1;
    }
}
